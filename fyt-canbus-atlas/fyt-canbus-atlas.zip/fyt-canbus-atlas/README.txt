FYT canbus protocol atlas
Which canbus profile on an FYT head unit decodes what, for all 5,106 profiles (652 protocols).
Built 2026-10-14 from a DUDUAUTO DUDU7 (com.syu.canbus build 2126013012).

  fyt-canbus-atlas.html     open in a browser: the interactive atlas, works offline
  fyt-canbus-protocols.md   the write-up: how decoding works, the ranking, the protocols
  fyt-canbus-profiles.csv   every settings entry with its decoder, parser, rank and signal counts
  fyt-canbus-spec.json      every decoded signal of every protocol (code, name, frame, byte expression)

Source and pipeline: https://github.com/erik-rosen/canbox-xc90-my2008/tree/main/fyt-canbus-atlas
